<?php
  $fname = $_POST['a1'];
  $fcon = $_POST['b1'];

  $myfile=fopen("data.txt", "a+");
  fwrite($myfile, $fname."\n");
  fwrite($myfile, $fcon."\n");
  echo fread($myfile, filesize("data.txt"));
  echo "저장되었습니다.";
  fclose($myfile);

?>
